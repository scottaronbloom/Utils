#include <ZenLib/Ztring.h>
ZenLib::Ztring Resources_Create ();
