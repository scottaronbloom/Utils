Java binding for MediaInfo DLL/SO

Three alternatives are possible depends on which "binding interface" you desire:
- JNI     (Java built in)
- JNA     http://jna.dev.java.net
- JNAtive http://jnative.sourceforge.net
