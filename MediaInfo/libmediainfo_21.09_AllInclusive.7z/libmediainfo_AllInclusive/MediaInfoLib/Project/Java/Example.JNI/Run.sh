java -cp .:JNI.jar HowToUse_Dll $1
